jquery-watermark
================

jQuery watermark plugin

Watermark plugin that displays watermark text for inputs.
It's doesn't use input val. 
Watermark disappears when user starts input text.
For now working text input from keyboard, from context menu, from keys (Ctrl+V etc)
Works on IE7+, Chrome, Firefox, Safari 5+
Only problem is browser's autocomplete.
