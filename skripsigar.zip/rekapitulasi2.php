﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Language" content="id" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Rekapitulasi Penghuni Rumah Nega</title>
<link rel="stylesheet" type="text/css" href="menucss.css" title="Style"></link>
</head>

<body class=standardteks>
	<?php 
		include("menukanan.htm");
		include("sambungan.php");
	?>

<p style="text-align: center" class="judul">Rekapitulasi Penghuni Rumah Negara</p>
<p><br /></p>
<p style="width: 421px; text-align: left; margin-left: 300px; color:maroon;">A. JUMLAH PENGHUNI PER KOMPLEK</p>
<table style="width: 70%; height: 67px; margin-left: 150px;" valign="center" border=0 id="tabel_a">
	<tr bgcolor="maroon" align="center" style="color:white;height:30px;">
		<td style="width: 27px">NO.</td>
		<td style="width: 67px">KOMPLEK</td>
		<td style="width: 40px">AKTIF</td>
		<td style="width: 40px">PURNA</td>
		<td style="width: 40px">WREDA</td>
		<td style="width: 40px">WARI</td>
		<td style="width: 40px">JANDA</td>
		<td style="width: 40px">DUDA</td>
		<td style="width: 40px">JUMLAH</td>
	</tr>
	<?php 
		
	?>
	<tr> 
		<td style="width: 27px; height: 30px;" align="center"><?php echo $hasil_rumah['ID_KOMPLEK'];?></td>
		<td style="width: 67px; height: 30px;">&nbsp;&nbsp;&nbsp;
		<?php 
		
		?>
		&nbsp;</td>
		<td style="width: 17px; height: 30px;" align="right">
		<?php 
		
		$jumlahtotal=0;
		$perintah_rumah="SELECT ID_KOMPLEK, COUNT(*) AS JMLPENGHUNI FROM TBL_RUMAH GROUP BY ID_KOMPLEK";
		$sql_rumah=mysql_query($perintah_rumah,$conn);
		while($hasil_rumah=mysql_fetch_array($sql_rumah)) {
		
			$idkomplek=$hasil_rumah['ID_KOMPLEK'];
			$perintah_komplek="SELECT * FROM TBL_KOMPLEK WHERE ID_KOMPLEK='$idkomplek';";
			$sql_komplek=mysql_query($perintah_komplek,$conn);
			$hasil_komplek=mysql_fetch_array($sql_komplek);
			echo $hasil_komplek['KOMPLEK'];
			
			$perintah_status="select kode_status, count(*) as jmlstatus from tbl_penghuni group by kode_status;";
			$sql_status=mysql_query($perintah_status,$conn);
			while($hasil_status=mysql_fetch_array($sql_status)){
			$jmlstatus=0;
			$kodestatus=$hasil_status['kode_status'];
			
			$perintahsemua ="select a.*,b.*,c.* 
						from tbl_rumah a,tbl_sip b,tbl_penghuni c 
						where a.id_komplek='$idkomplek' 
						and a.id_rumah=b.id_rumah 
						and b.nrp=c.nrp
						and c.kode_status=$kodestatus;";
						
			$sql=mysql_query($perintahsemua,$conn);
			while($hasil_status=mysql_fetch_array($sql_status)){
			$jmlstatus=$jmlstatus+1;
						}
			echo $jmlstatus."<BR>";
			}
		?></td>
		<td style="width: 17px; height: 30px;" align="right">&nbsp;</td>
		<td style="width: 17px; height: 30px;" align="right">&nbsp;</td>
		<td style="width: 17px; height: 30px;" align="right">&nbsp;</td>
		<td style="width: 17px; height: 30px;" align="right">&nbsp;</td>
		<td style="width: 17px; height: 30px;" align="right"><?php echo $hasil_rumah['JMLPENGHUNI']." Orang";
		$jumlahtotal=$jumlahtotal + $hasil_rumah['JMLPENGHUNI'];
		?>&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td style="width: 17px; height: 30px;" align="right">&nbsp;</td>
	</tr>
	<?php }?>
	<tr> 
		<td style="width: 27px; height: 30px;" align="center">&nbsp;</td>
		<td style="width: 67px; height: 30px;">&nbsp;</td>
		<td style="width: 17px; height: 30px;" align="right">
		&nbsp;</td>
		<td style="width: 17px; height: 30px;" align="right">&nbsp;</td>
		<td style="width: 17px; height: 30px;" align="right">&nbsp;</td>
		<td style="width: 17px; height: 30px;" align="right">&nbsp;</td>
		<td style="width: 17px; height: 30px;" align="right">&nbsp;</td>
		<td style="width: 17px; height: 30px;" align="right">&nbsp;</td>
		<td style="width: 17px; height: 30px;" align="right"><?php echo $jumlahtotal;?></td>
	</tr>
	</table><br>
<p style="width: 421px; text-align: left; margin-left: 293px;color:#0FF000;">B. Penghuni 
Berdasarkan Status</p>
<table style="width: 34%;" align="center" border=1>
	<tr>
		<td style="width: 27px">No.</td>
		<td style="width: 153px">Status</td>
		<td style="width: 187px">Jumlah</td>
	</tr>
	<?php 
		$perintah_status="select kode_status, count(*) as jmlstatus from tbl_penghuni group by kode_status;";
		$sql_status=mysql_query($perintah_status,$conn);
		while($hasil_status=mysql_fetch_array($sql_status)) {
	?>
	<tr>
		<td style="width: 27px"><?php echo $hasil_status['kode_status'];?></td>
		<td style="width: 153px"><?php 
			$idstatus=$hasil_status['kode_status'];
			$perintah_namastatus="select STATUS from TBL_STATUS where KODE_STATUS=$idstatus;";
			$sql_namastatus=mysql_query($perintah_namastatus,$conn);
			$hasil_namastatus=mysql_fetch_array($sql_namastatus);
			echo $hasil_namastatus['STATUS'];
		?></td>
		<td style="width: 187px"><?php echo $hasil_status['jmlstatus']." Orang";?></td>
	</tr>
	<?php }?>
</table>
<p style="width: 421px; text-align: left; margin-left: 293px">C. Jumlah SIP yang Expired</p>
<table style="width: 34%; margin-left: 293px">
	<tr>
		<td style="width: 27px">No.</td>
		<td style="width: 153px">Komplek</td>
		<td style="width: 187px">Jumlah</td>
	</tr>
	<tr>
		<td style="width: 27px">&nbsp;</td>
		<td style="width: 153px">&nbsp;</td>
		<td style="width: 187px" bgcolor="">&nbsp;</td>
	</tr>
</table>
<script language="javascript">
		
	var tabell=document.getElementById("tabel_a")
	var jmlbaris=tabell.rows.length
	var tanda=0;
	
	for (t=1; t<=jmlbaris; t++){
		if (tanda==1){
			tabell.rows[t].style.backgroundColor="#FFFCCC";
			tanda=0;
		}else {
			tabell.rows[t].style.backgroundColor="#FFFFFF";
			tanda=1;
		}
		
	}
</script>

</body>

</html>
