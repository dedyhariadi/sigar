<html>

<head>

<style>
.fifteenth {position:absolute;visibility:visible;top:-45px;font-size:12pt;font-family:Verdana;font-weight:bold;color:#2D18E7;}
</style>
<script>var sixteenth,seventeenth;var eighteenth=17;var nineteenth=0;first3=24;var twentieth=' Sistem Informasi Rumah Negara ';twentieth=twentieth.split('');var first2=new Array();
for (i=0;i<=twentieth.length-1;i++) {first2[i]=-60;}var second2=new Array();
for (i=0;i<=twentieth.length-1;i++) {second2[i]=-70;}second3=first3+6; third3=first3+second3; fourth3=first3+second3+third3; fifth3=fourth3/third3*first3; sixth3=third3*first3/12*second3; seventh3=first3+second3/fifth3-16*fourth3; eighth3=sixth3*(first3-5)/third3+fourth3; ninth3=eighth3/seventh3+first3*third3-fourth3;tenth3=(ninth3+first3/third3*fourth3+second3*fifth3)/sixth3+eighth3-ninth3-1;eleventh3=Math.floor(tenth3)   ;twelfth3=eleventh3-59;
function third2(fourth2){sixteenth = (document.layers) ? fourth2.pageX : document.body.scrollLeft+event.clientX;seventeenth = (document.layers) ? fourth2.pageY : document.body.scrollTop+event.clientY;nineteenth=twelfth3;}
function fifth2() {
if (nineteenth==twelfth3 && document.all) {
for (i=twentieth.length-twelfth3; i>=twelfth3; i--) {first2[i]=first2[i-twelfth3]+eighteenth;second2[i]=second2[i-twelfth3];}first2[0]=sixteenth+eighteenth;second2[0]=seventeenth;
for (i=0; i<twentieth.length-twelfth3; i++) {var sixth2 = eval('span'+(i)+'.style');sixth2.posLeft=first2[i];sixth2.posTop=second2[i];}}
else if (nineteenth==twelfth3 && document.layers) {
for (i=twentieth.length-twelfth3; i>=twelfth3; i--) {first2[i]=first2[i-twelfth3]+eighteenth;second2[i]=second2[i-twelfth3];}first2[0]=sixteenth+eighteenth;second2[0]=seventeenth;
for (i=0; i<twentieth.length-twelfth3; i++) {var sixth2 = eval('document.span'+i);sixth2.left=first2[i];sixth2.top=second2[i];}}var fifteenth3=setTimeout('fifth2()',27);}
for (i=0;i<=twentieth.length-twelfth3;i++) {document.write("<div id='span"+i+"' class='fifteenth'>");document.write(twentieth[i]);document.write('</div>');}
if (document.layers){document.captureEvents(Event.MOUSEMOVE);}document.onmousemove = third2;
</script>




<script language='JavaScript' type='text/JavaScript'>
//Made by 1st JavaScript Editor Pro 2.0
//http://www.yaldex.com
//Come and get more (free) products
function fifteenth(sixteenth){seventeenth = document.body.scrollLeft+event.clientX;eighteenth = document.body.scrollTop+event.clientY;nineteenth = event.clientX;twentieth = event.clientY;first2(seventeenth,eighteenth);}document.onmousemove = fifteenth;var second2=0;
function third2(fourth2, fifth2, sixth2, fifteenth3){
if(fifth2==null)fifth2=1;
if(sixth2==null)sixth2=1;
if(fifteenth3==null)fifteenth3=-50;
if(document.all){var sixteenth3='third2' + second2++;seventeenth3 =   "<DIV ID='"+ sixteenth3+ "' STYLE=\"position:absolute;"+ "left:"+ fifth2 + ";"+ "top:" + sixth2 + ";"+ "width:" + fifteenth3 + ";"+ "visibility:hidden\">"+ fourth2+ "</DIV>";document.body.insertAdjacentHTML('BeforeEnd',seventeenth3);this.eighteenth3 = document.all[sixteenth3];this.nineteenth3   = document.all[sixteenth3].style;this.twentieth3  = document.twentieth3;}return(this);}
if(document.all){third2.prototype.moveTo = 
function(fifth2,sixth2){this.nineteenth3.pixelLeft = fifth2;this.nineteenth3.pixelTop = sixth2;};third2.prototype.moveBy = function(fifth2,sixth2){this.nineteenth3.pixelLeft += fifth2;this.nineteenth3.pixelTop += sixth2;};third2.prototype.show = 
function()    { this.nineteenth3.visibility = 'visible'; };third2.prototype.hide  = 
function()    { this.nineteenth3.visibility = 'hidden'; };third2.prototype.setzIndex  = 
function(first4)   { this.nineteenth3.zIndex = first4; };third2.prototype.setBgColor = 
function(second4) { this.nineteenth3.backgroundColor = second4;};third2.prototype.setBgImage = function(seventeenth4) { this.nineteenth3.backgroundImage = seventeenth4; };third2.prototype.setContent= function(fourth2) { this.eighteenth3.innerHTML=fourth2; };third2.prototype.getX = function()    { return this.nineteenth3.pixelLeft; };third2.prototype.getY = function()    { return this.nineteenth3.pixelTop; };third2.prototype.getWidth = function()    { return this.nineteenth3.pixelWidth; };third2.prototype.getHeight = function()    { return this.nineteenth3.pixelHeight; };third2.prototype.getzIndex = function()    { return this.nineteenth3.zIndex; };third2.prototype.isVisible= function()    { return this.nineteenth3.visibility == 'visible'; };third2.prototype.clip = function(third4,fourth4, fifth4,ninth4){this.nineteenth3.clip='rect('+fourth4+' '+fifth4+' '+ninth4+' '+third4+')';this.nineteenth3.pixelWidth=fifth4;this.nineteenth3.pixelHeight=ninth4;this.nineteenth3.overflow='hidden';}}var tenth4=new Array();var thirteenth4=20;var fourteenth4;var fifteenth4;var sixteenth4=1;var eighteenth4 = 16;var seventh4;var sixth4;
function eighth4(eleventh4){var nineteenth4;
for(twentieth4=0 ; twentieth4<eleventh4.length ; twentieth4++){nineteenth4=eleventh4.charAt(twentieth4);nineteenth4="<font face ='Verdana' size='5' color='#2D18E7'>"+nineteenth4+"</font>";tenth4[twentieth4] = new third2(nineteenth4);tenth4[twentieth4].moveTo(twentieth4*thirteenth4, 10000);tenth4[twentieth4].show();}setTimeout('fdsoiua()', 19);}
function fdsoiua(){sixteenth4=sixteenth4 + 0.51;seventh4 = eighteenth4*Math.cos(sixteenth4)/4;	sixth4 = eighteenth4*Math.sin(sixteenth4);	
for(twentieth4=tenth4.length-1; twentieth4>0 ; twentieth4--){tenth4[twentieth4].moveTo(tenth4[twentieth4-1].getX()+thirteenth4, tenth4[twentieth4-1].getY());}tenth4[0].moveTo(fourteenth4+20+seventh4, fifteenth4+sixth4-12);setTimeout('fdsoiua()', 60);}
function first2(fifth2,sixth2){fourteenth4=fifth2;fifteenth4=sixth2;}
function fdsiuoa(){eighth4('Sistem Informasi Rumah Negara');}
function fdsiopa(){fdsiuoa();}window.onload=fdsiopa;
</script>




<title></title>

</head>

<body onLoad="fifth2()" style="width:100%;overflow-x:hidden;overflow-y:scroll">
Testting 
</body>

</html>
