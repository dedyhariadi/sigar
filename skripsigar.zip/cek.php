<?php
session_start();
unset($_SESSION['namauser']);
//echo "Anda telah logout";
?>
<p style="color:red;size:50px" align=center>Anda telah keluar</p>