<?php
//session_destroy();
//session_name("AUTHEN");

?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>..:: Sistem Informasi Personel Lantamal V ::..</title>

<link rel="stylesheet" type="text/css" href="menucss.css" title="Style"> </link>

<link href="Gambar/logo.png" rel="SHORTCUT ICON">

<style type="text/css">
<!--
body {
	background-color: #FBFBF9;
}
#form1 table {
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
}
.style1 {
	text-align: left;
}
.style2 {
	text-align: center;
}
.style3 {
	font-family: Meiryo;
	text-align: center;
	border-bottom-style: groove;
}
.style4 {
	letter-spacing: 3pt;
	font-size: x-large;
	background-color: #C0C0C0;
}
.style5 {
	font-family: "Plantagenet Cherokee";
	font-size: medium;
}
.style6 {
	letter-spacing: 3pt;
	font-size: x-large;
}
.style7 {
	text-align: center;
	background-color: #FFFFFF;
	padding: 0px;
}
.style3 {
	border-bottom-style: groove;
}
.style9 {
	font-family: "Plantagenet Cherokee";
	font-size: 3pt;
	color: #FFFFFF;
}
.style10 {
	background-color: #FFFFFF;
}
.style11 {
	letter-spacing: -3pt;
	font-size: x-large;
	background-color: #FFFFFF;
	vertical-align: middle;
}
-->
</style>
</head>

<body>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<form method="POST" action="proses.php">

<table style="width: 27%" align="center">
	<tr>
		<td rowspan="4">
		<img alt="Disminpers" src="Gambar/logo2.png" width="120" height="137"></td>
		<td colspan="3" class="style3" style="height: 24px"><span class="style6">LOG</span><strong><span class="style11"><span class="style10">IN</span></span><span class="style4"><span class="style10"><br>
		</span></span></strong></td>
	</tr>
	<tr>
		<td class="style9" colspan="3">a</td>
	</tr>
	<tr>
		<td class="standardteks">User</td>
		<td>:</td>
		<td class="style7">
			<input name="nama_pengguna" type="text">
		</td>
	</tr>
	<tr>
		<td class="standardteks">Password</td>
		<td>:</td>
		<td>
			<input name="kata_kunci" type="password">
		</td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td>&nbsp;</td>
		<td>&nbsp;</td>
		<td class="style1">&nbsp;</td>
	</tr>
	<tr>
		<td colspan="4" class="style2">

			<input name="simpan" type="submit" value="Masuk"></form>
		</td>
	</tr>
</table>
</body>
</html>
