﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Language" content="id" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>KOMANDO ARMADA RI KAWASAN TIMUR</title>
</head>

<body style="font-family: Arial, Helvetica, sans-serif; font-size: 13px; margin-left: 40px;">

<p style="width: 436px; font-family: Arial, Helvetica, sans-serif; text-align: center; font-size: 16px">
SETIAP PEMEGANG SIP RUMAH NEGARA<br />
DILARANG UNTUK</p>
<p style="width: 437px; font-family: Arial, Helvetica, sans-serif; font-size: 16px; text-align: justify;">
1.&nbsp;&nbsp;&nbsp;Mengubah, menambah atau mengurangi bentuk rumah yang dihuni 
sebelum mendapat izin dari dinas</p>
<p style="width: 436px; font-size: 16px; text-align: justify;">2.&nbsp;&nbsp;&nbsp;Menyerahkan / mengontrakkan 
atau meminjamkan sebagian atau seluruhnya rumah dinas kepada orang lain</p>
<p style="width: 436px; font-size: 16px; text-align: justify;">3.&nbsp;&nbsp;&nbsp; Menggunakan sebagian atau 
seluruhnya rumah dinas untuk keperluan usaha / toko / perusahaan / kantor tanpa seizin 
dinas.</p>
<p style="width: 434px; text-align: justify; font-size: 16px;">4.&nbsp;&nbsp;&nbsp; Memperjualbelikan SIP</p>
<p style="width: 434px; text-align: center; font-size: 16px;">DENAH UKURAN RUMAH DAN HALAMAN<br />
YANG DIIZINKAN UNTUK DITEMPATI</p>
<I
    <br />
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <?php 
      
	$id_rumah = strtoupper($_GET['id_rumah']);
    $gambar="Denah/".$id_rumah.".jpg";
      ?>
      <img src="<?php echo $gambar;?>" width="367" height="350"/>&nbsp;
</body>

</html>
