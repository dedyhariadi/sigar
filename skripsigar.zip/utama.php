﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Language" content="en-us" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sistem Informasi Rumah Negara</title>
<link rel="stylesheet" type="text/css" href="menucss.css" title="Style" />

</head>

<body bgcolor="#FBFBF9">

<?php 
	include("menuatas.php");
?>
<br/>
<table style="width: 45%; height: 200px; border-color:white;" align="center" bgcolor="#F2E6FF" cellspacing="0">
	<tr>
		<td style="height: 23px" align="center"><a href="rmhbaru.php">
		<img alt="Rumah Negara Baru" src="Gambar/home.jpg" width="120" height="137" border="0" /></a><br />
		</td>
		<td style="height: 23px; width: 25%;" align="center" ><a href="update_menu.php">
		<img alt="Perubahan Data Rumah" src="Gambar/update.jpg" width="88" height="88" border="0" /></a></td>
		<td style="height: 23px; width: 25%" align="center"><a href="sip_komplek.php">
		<img alt="Mencetak SIP" src="Gambar/icon-printer.png" width="120" height="120" border="0" /></a><br />
		</td>
		<td style="height: 23px; width: 25%;" align="center"><a href="laporan.php">
		<img alt="Mencetak Laporan Triwulan" src="Gambar/laporan.jpg" width="100" height="69" border="0" /></a><br />
		</td>
	</tr>
	<tr>
		<td style="height: 38px" align="center">
		<a href="rmhbaru.php">Rumah Baru</a></td>
		<td style="width: 25%; height: 38px;" align="center">
		<a href="update_menu.php">Update</a></td>
		<td style="width: 25%; height: 38px;" align="center">
		<a href="sip_komplek.php">S I P</a></td>
		<td style="width: 25%; height: 38px;" align="center"><a href="laporan.php">Laporan Triwulan</a></td>
	</tr>
	<tr bgcolor="white" style="border-color:white">
		<td align="center" style="height: 23px" colspan="4" style="border-left-color:white">	</td>
	</tr>
	<tr>
		<td style="height: 23px" align="center"><a href="lampiran.php" >
		<img alt="Lampiran Untuk Pengajuan SIP" src="Gambar/lampiran2.jpg" width="105" height="104" border="0" /></a><br />
		</td>
		<td align="center" style="width: 25%; height: 23px;"><a href="masalah_menu.php">
		<img alt="aaa" src="Gambar/Pensiun.jpg" width="115" height="104" border="0" /></a></td>
		<td align="center" style="width: 25%; height: 23px;"><a href="rekapitulasi.php" >
		<img alt="Rekapitulasi Rumah Negara" src="Gambar/rekapitulasi.jpg" width="108" height="108" border="0" /></a><br />
		</td>
		<td align="center" style="width: 25%; height: 23px;"><a href="ovb.php">
		<img alt="Administrasi User" src="Gambar/padi.jpg" width="132" height="69" border="0" /></a><br />
		</td>
	</tr>
	<tr style="height:35px;">
		<td align="center">
		<a href="lampiran.php" >Lampiran Pengajuan</a></td>
		<td style="width: 25%" align="center">
		<a href="masalah_menu.php">Rumneg Bermasalah</a></td>
		<td align="center" style="width: 25%">
		<a href="rekapitulasi.php" >Rekapitulasi</a></td>
		<td align="center" style="width: 25%">
		<a href="ovb.php">O V B</a></td>
	</tr>
</table>
</body>

</html>
