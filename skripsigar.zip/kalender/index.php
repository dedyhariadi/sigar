<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="us" lang="us">
<head>
<title>PHP Calendar</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script src="php_calendar/scripts.js" type="text/javascript"></script>
</head>
<body>
<h1>PHP Calendar</h1>
<p>This is the example of PHP Calendar</p>
<form action="index.php">
<fieldset>
<input type="text" name="date" id="date" />
<a href="javascript:viewcalendar()">calendar</a>
</fieldset>
</form>
<p>Created by <a href="http://www.separdsoft.sk">SepardSoft</a></p>
</body>
</html>
