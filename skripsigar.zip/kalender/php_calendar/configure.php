<?php
$month_names = array(1=>'january', 2=>'february', 3=>'march', 4=>'april', 5=>'may', 6=>'june', 7=>'july', 8=>'august', 9=>'september', 10=>'october', 11=>'november', 12=>'december');
$day_names = array('MO', 'TU', 'WE', 'TH', 'FR', 'SA', 'SU');
$allow_past = false;
$date_format = 'd.m.Y';
?>
