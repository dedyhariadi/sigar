<?php

/**
 * @author subdiswatpers
 * @copyright 2013
 */

require('fpdf.php');

$pdf=new FPDF('P','mm','A5');
$pdf->SetMargins(10,10,10);
$pdf->AddPage();
$pdf->SetFont('Arial','',9.5);
$pdf->MultiCell(69,3,'KOMANDO ARMADA RI KAWASAN TIMUR    ANGKALAN UTAMA TNI AL V',0,'C');
$pdf->Ln();
//$pdf->Cell(70,4,'',1,'R');
$pdf->Line(11,18,78,18);
$pdf->Ln();
$pdf->Ln();
$pdf->Ln();
$pdf->MultiCell(132,3,'SURAT IZIN PENGHUNIAN RUMAH NEGARA',0,'C');
$pdf->MultiCell(132,3,'Nomor : SIP/',0,'C');
$pdf->Ln();
$pdf->MultiCell(132,4,'1.   Diizinkan kepada :',0,'L');
$pdf->MultiCell(132,4,'      Nama                   :',0,'L');
$pdf->MultiCell(132,4,'      Pangkat, NRP / NIP     :',0,'L');
$pdf->MultiCell(132,4,'      Jabatan                 :',0,'L');
$pdf->MultiCell(132,4,'      Satker                  :',0,'L');
$pdf->Ln();
$pdf->MultiCell(132,4,'2.   Untuk Menempati rumah:',0,'L');
$pdf->MultiCell(132,4,'      Alamat                  :',0,'L');
$pdf->MultiCell(132,4,'      Sebagian/Seluruhnya     :',0,'L');
$pdf->MultiCell(132,4,'      Tipe rumah              :',0,'L');
$pdf->MultiCell(132,4,'      Dipakai untuk           :',0,'L');
$pdf->MultiCell(132,4,'      Terhitung mulai         :',0,'L');
$pdf->MultiCell(132,4,'      Berlaku sampai          :',0,'L');
$pdf->Ln();
$pdf->MultiCell(132,4,'3.   Jumlah Keluarga ',0,'L');

$pdf->Output();

?>