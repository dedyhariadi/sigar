<?php
session_start();
unset($_SESSION['namauser']);
//echo "Anda telah logout";
?>
<br><br><br><br><br><br>
<p style="color:red;" align=center><font size=50>Anda telah keluar</font><br>
<a href="index.php">Kembali login</a></p>