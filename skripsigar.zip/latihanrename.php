<?php
rename('C:\rumah.jpg', 'C:\HTH1.gif');
       
//exec($cmd, $output, $return_val);
//
//if ($return_val == 0) {
//   echo "success";
//} else {
//   echo "failed";
//}
?>